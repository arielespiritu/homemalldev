@extends('client.master.master')

@section('title', 'Market Place')

@section('content')

    <div id="all">
			<div id="main-slider" style="margin-top:-15px;"> 
				<div class="item" style="background:#a22221;">
					<center><img class="img-responsive" src="{{ URL::asset('assets/img/banner4.png') }}" alt=""></center>
				</div>	
				<div class="item"  style="background:#b3a387;">
					<center><img src="{{ URL::asset('assets/img/banner1.png') }}" alt="" class="img-responsive"></center>
				</div>
				<div class="item" style="background:#32ace8;" >
					<center><img class="img-responsive" src="{{ URL::asset('assets/img/banner2.png') }}" alt=""></center>
				</div>
				<div class="item" >
					<center><img class="img-responsive" src="{{ URL::asset('assets/img/banner3.png') }}" alt=""></center>
				</div>						
			</div>
	</div>
   
		<div id="hot" style="margin-top:10px;">
			<div class="container" >
				<div class="col-md-12" style="padding:0px;" >
					<div class="col-md-12 box" >
						<img class="img-responsive" src="{{ URL::asset('assets/img/market/featuredItem.png') }}" alt="Homemallph Market">
					</div>
					<div class="col-md-12" style="padding:0px" id="featured-products">
					@foreach($featured_products as $featured_products )
						<div class="col-md-3 col-xs-6" style="padding:2px; margin-top:-23px;">
							<div class="box" >
							
								<a href="/Product/Details/{{$featured_products->product_info->id}}/{{encodeUrlRoute($featured_products->product_info->product_name)}}"><center><img class="img-responsive" src="{{ URL::asset('assets/img/category/grocery/1.png') }}" alt=""></center></a>
								<div class="item-desc" style="padding:10px" >
									<a href="/Product/Details/{{$featured_products->product_info->id}}/{{encodeUrlRoute($featured_products->product_info->product_name)}}"><h4 >{{$featured_products->product_info->product_name}}</h4></a>
									<?php $count=0;?>
									@foreach($featured_products->product_info->product as $product )
										@if($count==0)
										<?php $count++;?>
										<h4><p >&#8369;&nbsp;&nbsp;{{$product->sale_price}}</p></h4>
										@endif
									@endforeach	
								</div>
							</div>
						</div>
					@endforeach	
					</div>

				</div>
			</div>
			<div class="container" >
				<div class="col-md-12" style="padding:0px; margin-top:-26px; margin-bottom:-26px" >
						<div class="col-md-12 box" >
							<img class="img-responsive" src="{{ URL::asset('assets/img/market/markets.png') }}" alt="Homemallph Market">
						</div>
				</div>
			</div>			

			<?php 
				$bg=array("#f6ecb7","#103f71","#ca27f4","#4a79f5"); 
				$num = 0;
			?>
			@foreach($market_data as $markets_datas )
			<?php $count=0; ?>
				
			<div class="box"  style="background:{{$bg[$num]}}; padding:0px; margin-top:80px;  margin-bottom:10px;">
				<center><img class="img-responsive" style="margin-top:-80px;" src="{{ URL::asset('assets/img/market/'.$markets_datas->market_name.'-add.png') }}" alt=""></center>
			</div>
			<div style="clear: both;"></div>
			<div class="container">

						<div style="clear: both;"></div>
                        <div class="col-md-12 market box" >
							
							<div class="col-md-3 same-height-row" style="padding:0px; ">
								<div class="col-md-12  market-logo" >
									 <a  href="/{{$markets_datas->market_name}}"><center><img class="img-responsive" src="{{ URL::asset('assets/img/market/'.$markets_datas->market_name.'.png') }}" alt=""></center></a>
								</div>
							</div>
							<div class="col-md-9 same-height-row" style="padding:0px; ">
							@foreach($markets_datas->categoryStore as $category_store )
								@foreach($category_store->subCategoryStore as $subCategory_store )
									@foreach($subCategory_store->productsStore as $products_store )
										<a  href="/Store/{{$products_store->store_id}}"><div class="col-md-4  col-xs-6 store-logo" >
											<div class="wraptocenter"><span></span><img src="{{ URL::asset(getStoreBanner($products_store->store->store_name)) }}" alt="..."></div>
										</div></a>
									@endforeach	
								@endforeach	
							@endforeach							
							</div>
                        </div>
                </div>
				
				
				
				<div class="container" >
						@foreach($markets_datas->categoryStore as $category_store )
							@if($count<4)
							<?php $count++; ?>
								<div class="col-md-3 col-xs-6" style="padding:2px; margin-bottom:-25px;">
									<div class="box">
										<a href="/{{$markets_datas->market_name}}/Category/{{str_replace(' ','-',$category_store->category_name)}}/All"> <center><img class="img-responsive"  data-src="{{ URL::asset('assets/img/category/'.$markets_datas->market_name.'/'.$category_store->id.'.png') }}" data-src-retina="{{ URL::asset('assets/img/category/'.$markets_datas->market_name.'/'.$category_store->id.'.png') }}" src="{{ URL::asset('assets/img/loading.gif') }}" alt="" /></center></a>
										<div class="list-group" style="margin-bottom:0px; border-radius: 0px 0px 0px 0px; " >
										<?php $prodCounts=0; ?>
										@foreach($category_store->subCategoryStore as $subCategory_store )
											@if($prodCounts<3)
												@foreach($subCategory_store->products_random as $products_random )
													<a href="/Product/Details/{{$products_random->id}}/{{encodeUrlRoute($products_random->product_name)}}" class="list-group-item category-products"  >
														<?php $imgCounts=0; ?>
														@foreach($products_random->product as $product )
															@if($imgCounts==0)
															<img class="alignleft"  data-src="{{ URL::asset(getSingleImageProduct($product->id,$products_random->store->store_name)) }}" data-src-retina="" src="{{ URL::asset('assets/img/loading.gif') }}" alt="" />
															<?php $imgCounts++; ?>
															@endif
														@endforeach	
														<b><h5 class="list-group-item-heading">{{$products_random->product_name}}</h5></b>
														<p class="list-group-item-text">P 100.00</p>
													</a>

												@endforeach
											<?php $prodCounts++; ?>
											@endif
										@endforeach	
										</div>
									</div>
								</div>
							@endif
						@endforeach	
						
						<!--<div class="col-md-12 " style="padding:0px; margin-top:10px;"  >
							<div id="textbox">
								  <a  href="/market/{{strtolower($markets_datas->market_name)}}" class="alignright" style="margin-top:-20px;">See More</a>
							</div>
						</div>-->
					</div>

                </div>
     		<?php $num++; ?>
			@endforeach	
				
			
           <div class="container" >
				<div class="col-md-12" style="padding:2px; margin-top:10px;">
					<div class="col-md-12 box" >
						<img class="img-responsive" src="{{ URL::asset('assets/img/market/brands.png') }}" alt="Homemallph Market">
					</div>
				</div>
			</div>
            <div class="container" >
                <div class="col-md-12" style="padding:2px; margin-top:-25px;" >
                    <div class="box" >
                        <div id="get-inspired" class="owl-carousel owl-theme">
                            <div class="item">
                               <div class="col-sm-12 " style="padding:0px;  ">
									<div class="col-sm-12 same-height-row" style="padding:0px; ">	
										@foreach($brands_data as $brands_data )
										<div class="col-sm-2 col-xs-6 store-logo" >
											<div class="wraptocenter"><span></span><img src="{{ URL::asset('assets/img/brand/'.$brands_data->id.'.png') }}" alt="..."></div>
										</div>	
										@endforeach	
									</div>
								</div>	
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
			<div class="container" >
				<div class="col-md-12" style="padding:2px; margin-top:-25px;" >
					<div class="col-md-12 box" >
						<img class="img-responsive" src="{{ URL::asset('assets/img/market/trends.png') }}" alt="Homemallph Market">
					</div>
					<div class="col-md-12" style="padding:0px">
					@for ($x = 0; $x < 12; $x++)
						<div class="col-md-2 col-xs-6" style="padding:2px; margin-top:-23px;">
								<div class="box">
										<a href="/Product/Details/1/Ariel-Sample"><center><img class="img-responsive" src="{{ URL::asset('assets/img/category/grocery/1.png') }}" alt=""></center></a>
										<div class="item-desc" style="padding:10px" >
											<a href="/Product/Details/1/Ariel-Sample"><h4 >Product Namessssssss</h4>
											<a href="/Product/Details/1/Ariel-Sample"><p >P 100.00</p></h4>										
										</div>
								</div>
						</div>
					@endfor	
					</div>
				</div>
			</div>
            
        
		
		<div style="background:#fff;" >
		<div class="container">
            <div class="row">
			<br>
				<div class="col-md-12" style="padding:0px;">
					<div class="col-md-2 img-footer" style="padding:20px;" >
						<center>
							<img class="" src="{{ URL::asset('assets/img/convenience.png') }}" alt="..." >
							<h4 class="text-center">Convenience</h4>
							<p class="text-center">You don't need to get dressed and  drive to your favorite store.</p>
						</center>
					</div>
					<div class="col-md-2 img-footer" style="padding:20px" >
						<center>
							<img class="" src="{{ URL::asset('assets/img/DeliveryIcon.png') }}" alt="..." >
							<h4 class="text-center">Shipping</h4>
							<p class="text-center"> We ship first in National Capital Region (NCR) with our logisctic partner.</p>
						</center>
					</div>
					<div class="col-md-2 img-footer" style="padding:20px" >
						<center>
							<img class="" src="{{ URL::asset('assets/img/SafePayment.png') }}" alt="..." >
							<h4 class="text-center">Payment</h4>
							<p class="text-center"> Pay with the world’s most popular and secure payment methods..</p>
						</center>
					</div>
					<div class="col-md-2 img-footer" style="padding:20px" >
						<center>
							<img class="" src="{{ URL::asset('assets/img/ShopWithConfidence.png') }}" alt="..." >
							<h4 class="text-center">Shop with Confidence</h4>
							<p class="text-center"> Our Buyer Protection covers your purchase from click to delivery..</p>
						</center>
					</div>
					<div class="col-md-2 img-footer" style="padding:20px" >
						<center>
							<img class="" src="{{ URL::asset('assets/img/HelpCenter.png') }}" alt="..." >
							<h4 class="text-center">24/7 Help Center</h4>
							<p class="text-center"> Round-the-clock assistance for a smooth shopping experience..</p>
						</center>
					</div>
					<div class="col-md-2" style="padding:20px" >
						<center>
						</br>
							<img class="" src="{{ URL::asset('assets/img/1googlePlay.png') }}" alt="..." style="height:30px; width:120px;" >
							<h4 class="text-center">Andriod app</h4>
							<p class="text-center"> Download the app and get the world of HomeMallPH at your fingertips..</p>
						</center>
					</div>
				
				</div>

			</div>
		</div>
	</div>
						
@endsection


@section('page-script')
	

	<script type="text/javascript">

			
			
			
	function getFeaturedProducts(){
		$.post("/References/Barangay/Delete", {id : id}, function(result){	

		});
	}		
	</script>
	
	
	
@endsection