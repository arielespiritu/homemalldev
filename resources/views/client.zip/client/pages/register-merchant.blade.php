@extends('client.master.master-plain')

@section('title', 'Register')

@section('content')

			
			<div class="container" style="margin-top:-17px;">
				<div class="col-md-12 " style="padding:2px; "  >
					<div class="col-md-4  col-md-offset-4 col-xs-4  box" style="padding:15px;">
					
                        <h3>Order summary</h3>
                     
                        <p class="text-muted">Shipping and additional costs are calculated based on the values you have entered.</p>

					</div>
                </div> 
            </div>				
@endsection


@section('page-script')
<script>

</script>	
	
@endsection