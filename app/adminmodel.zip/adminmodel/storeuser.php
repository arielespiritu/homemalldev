<?php

namespace App\adminmodel;

use Illuminate\Database\Eloquent\Model;

class storeuser extends Model
{
    //
}
