<?php

namespace App\adminmodel;

use Illuminate\Database\Eloquent\Model;

class storeinfo extends Model
{
   protected $table = 'store_tbl';   
}
