<?php

namespace App\adminmodel;

use Illuminate\Database\Eloquent\Model;

class indicator extends Model
{
     protected $table = 'indicator_tbl';   
}
